package TDAColaPrioridad;
public class InvalidKeyException extends Exception {

	public InvalidKeyException(String arg0) {
		super(arg0);
	}
}
